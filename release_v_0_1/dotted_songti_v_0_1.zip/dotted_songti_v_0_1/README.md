# DottedSongti OpenType fonts v0.1

Created by wixette. 2020.05.08.

See https://github.com/wixette/dotted-chinese-fonts for more info.
